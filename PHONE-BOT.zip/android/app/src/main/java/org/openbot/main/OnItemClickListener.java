package org.openbot.main;

public interface OnItemClickListener<T> {
  void onItemClick(T item);
}
