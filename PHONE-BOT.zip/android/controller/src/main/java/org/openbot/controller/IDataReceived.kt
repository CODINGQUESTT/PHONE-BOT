package org.openbot.controller

interface IDataReceived {
    fun dataReceived(command: String?)
}